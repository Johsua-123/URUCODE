<aside class="sidebar">
    <header>
        <a href="http://localhost/URUCODE/admin">
            <img src="../public/icons/errea.png" alt="logo de errea">
            <h1>Errea</h1>
        </a>
    </header>
    <footer>
        <a href="index.php" class="<?php echo $location == "index" ? "sidebar-active" : "" ?>">Inicio</a>
        <a href="tienda.php" class="<?php echo $location == "tienda" ? "sidebar-active" : "" ?>">Tienda</a>
        <a href="ventas.php" class="<?php echo $location == "ventas" ? "sidebar-active" : "" ?>">Ventas</a>
        <a href="cuentas.php" class="<?php echo $location == "cuentas" ? "sidebar-active" : "" ?>">Cuentas</a>
        <a href="inventario.php" class="<?php echo $location == "inventario" ? "sidebar-active" : "" ?>">Inventario</a>
        <a href="categorias.php" class="<?php echo $location == "categorias" ? "sidebar-active" : "" ?>">Categorías</a>
        <a href="mensajes.php" class="<?php echo $location == "mensajes" ? "sidebar-active" : "" ?>">Mensajes</a>
    </footer>
</aside>
