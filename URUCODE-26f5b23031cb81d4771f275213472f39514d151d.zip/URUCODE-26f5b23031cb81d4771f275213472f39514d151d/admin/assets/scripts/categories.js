function toggleModal() {
    const modal = document.getElementById("categoryModal");
    modal.classList.toggle("hidden");
}
